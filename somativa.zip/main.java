import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Financiamento {
    private double valorImovel;
    private int prazoFinanciamento;
    private double taxaJurosAnual;

    public Financiamento(double valorImovel, int prazoFinanciamento, double taxaJurosAnual) {
        this.valorImovel = valorImovel;
        this.prazoFinanciamento = prazoFinanciamento;
        this.taxaJurosAnual = taxaJurosAnual;
    }

    public double calcularPagamentoMensal() {
        return (valorImovel / prazoFinanciamento) * (1 + (taxaJurosAnual / 12));
    }

    public double calcularTotalPagamento() {
        return calcularPagamentoMensal() * prazoFinanciamento;
    }

    // Getters
    public double getValorImovel() {
        return valorImovel;
    }

    // Método para obter o valor do financiamento
    public double getValorFinanciamento() {
        return calcularTotalPagamento() - getValorImovel();
    }
}

class InterfaceUsuario {
    private Scanner scanner;

    public InterfaceUsuario() {
        scanner = new Scanner(System.in);
    }

    // Método para validar e obter valor do imóvel
    public double pedirValorImovel() {
        double valor;
        do {
            System.out.print("Digite o valor do imóvel: ");
            valor = scanner.nextDouble();
        } while (valor <= 0);
        return valor;
    }

    // Método para validar e obter prazo de financiamento
    public int pedirPrazoFinanciamento() {
        int prazo;
        do {
            System.out.print("Digite o prazo do financiamento em anos: ");
            prazo = scanner.nextInt();
        } while (prazo <= 0);
        return prazo;
    }

    // Método para validar e obter taxa de juros
    public double pedirTaxaJuros() {
        double taxa;
        do {
            System.out.print("Digite a taxa de juros anual: ");
            taxa = scanner.nextDouble();
        } while (taxa <= 0);
        return taxa;
    }
}

public class Main {
    public static void main(String[] args) {
        InterfaceUsuario interfaceUsuario = new InterfaceUsuario();

        // Lista para armazenar os financiamentos
        List<Financiamento> financiamentos = new ArrayList<>();

        // Adicionando quatro financiamentos à lista
        for (int i = 1; i <= 4; i++) {
            System.out.println("Financiamento " + i + ":");
            double valorImovel = interfaceUsuario.pedirValorImovel();
            int prazoFinanciamento = interfaceUsuario.pedirPrazoFinanciamento();
            double taxaJurosAnual = interfaceUsuario.pedirTaxaJuros();

            Financiamento financiamento = new Financiamento(valorImovel, prazoFinanciamento, taxaJurosAnual);
            financiamentos.add(financiamento);
        }

        // Exibindo informações de cada financiamento
        for (int i = 0; i < financiamentos.size(); i++) {
            System.out.println("Financiamento " + (i + 1) + " - Valor do Imóvel: R$ " + financiamentos.get(i).getValorImovel()
                    + ", Valor do Financiamento: R$ " + financiamentos.get(i).getValorFinanciamento());
        }

        // Calculando e exibindo o valor total de todos os imóveis e financiamentos
        double totalImoveis = financiamentos.stream().mapToDouble(Financiamento::getValorImovel).sum();
        double totalFinanciamentos = financiamentos.stream().mapToDouble(Financiamento::getValorFinanciamento).sum();

        System.out.println("Total de todos os imóveis: R$ " + totalImoveis);
        System.out.println("Total de todos os financiamentos: R$ " + totalFinanciamentos);
    }
}
